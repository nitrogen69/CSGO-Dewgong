#include "hooks.hpp"
#include <intrin.h>  

#include "menu.hpp"
#include "options.hpp"
#include "helpers/input.hpp"
#include "helpers/utils.hpp"
#include "features/bhop.hpp"
#include "features/chams.hpp"
#include "features/visuals.hpp"
#include "features/glow.hpp"
#include "skins.h"
#include "aimbot.h"
#include "backtrack.h"

#pragma intrinsic(_ReturnAddress)  

#include <3DMath.h>
#include "imgui/impl/imgui_impl_dx9.h"
#include <winuser.h>

namespace Hooks
{
	WNDPROC OriginalWndProc;
	LRESULT CALLBACK hkWndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
	{
		if (g_menu.IsVisible())
		{
			ImGui_ImplWin32_WndProcHandler(hwnd, msg, wParam, lParam);
			return TRUE;
		}
		return CallWindowProc(OriginalWndProc, hwnd, msg, wParam, lParam);
	}

	HRESULT STDMETHODCALLTYPE hkEndScene(IDirect3DDevice9* device)
	{
		static auto viewmodel_fov = g_CVar->FindVar("viewmodel_fov");
		static auto mat_ambient_light_r = g_CVar->FindVar("mat_ambient_light_r");
		static auto mat_ambient_light_g = g_CVar->FindVar("mat_ambient_light_g");
		static auto mat_ambient_light_b = g_CVar->FindVar("mat_ambient_light_b");
		static auto crosshair_cvar = g_CVar->FindVar("crosshair");

		viewmodel_fov->m_fnChangeCallbacks.m_Size = 0;
		viewmodel_fov->SetValue(g_Options.viewmodel_fov);
		mat_ambient_light_r->SetValue(g_Options.mat_ambient_light_r);
		mat_ambient_light_g->SetValue(g_Options.mat_ambient_light_g);
		mat_ambient_light_b->SetValue(g_Options.mat_ambient_light_b);
		crosshair_cvar->SetValue(!g_Options.esp_crosshair);

		DWORD dwOld_D3DRS_COLORWRITEENABLE;

		device->GetRenderState(D3DRS_COLORWRITEENABLE, &dwOld_D3DRS_COLORWRITEENABLE);
		device->SetRenderState(D3DRS_COLORWRITEENABLE, 0xffffffff);

		g_menu.Render();

		device->SetRenderState(D3DRS_COLORWRITEENABLE, dwOld_D3DRS_COLORWRITEENABLE);

		if (g_win_input.IsKeyDown(VK_TAB))
			Utils::RankRevealAll();

		if (g_win_input.IsKeyPressed(VK_F4))
			g_ClientState->ForceFullUpdate();

		return VmtHook(device, index::EndScene, &hkEndScene, OriginalEndScene), OriginalEndScene(device);
	}

	HRESULT STDMETHODCALLTYPE hkReset(IDirect3DDevice9* device, D3DPRESENT_PARAMETERS* pPresentationParameters)
	{
		Visuals::DestroyFonts();
		g_menu.OnDeviceLost();

		auto hr = OriginalReset(device, pPresentationParameters);

		if (SUCCEEDED(hr))
		{
			g_menu.OnDeviceReset();
			Visuals::CreateFonts();
		}
		return hr;
	}
	
	void __stdcall hkCreateMove(int sequence_number, float input_sample_frametime, bool active, bool& bSendPacket)
	{
		OriginalCreateMove(g_CHLClient, sequence_number, input_sample_frametime, active);

		auto cmd = g_Input->GetUserCmd(sequence_number);
		auto verified = g_Input->GetVerifiedCmd(sequence_number);

		if (!cmd || !cmd->command_number)
			return;

		g_Aimbot.OnMove(cmd);
		g_Backtrack.OnMove(cmd);

		if (g_Options.misc_bhop)
			BunnyHop::OnCreateMove(cmd);

		verified->m_cmd = *cmd;
		verified->m_crc = cmd->GetChecksum();
	}

	bool __fastcall hkCreateMove2(void* thisptr, void*, float frame_time, CUserCmd* cmd)
	{
		if (!cmd->command_number)
			return OriginalCreateMove2(thisptr, frame_time, cmd);
		//g_Aimbot.OnMove(cmd);
		static float smoothing = 40;
		Aim::OnCreateMove(cmd, smoothing * frame_time);
		Aim::FixRecoil(cmd);
		g_Backtrack.OnMove(cmd);
		BunnyHop::OnCreateMove(cmd);
		return false;
	}
	
	void __declspec(naked) __stdcall hkCreateMove_Proxy(int sequence_number, float input_sample_frametime, bool active)
	{
		__asm
		{
			push ebp
			mov  ebp, esp
			push ebx
			lea  ecx, [esp]
			push ecx
			push dword ptr[active]
			push dword ptr[input_sample_frametime]
			push dword ptr[sequence_number]
			call Hooks::hkCreateMove
			pop  ebx
			pop  ebp
			retn 0Ch
		}
	}

	void __stdcall hkPaintTraverse(vgui::VPANEL panel, bool forceRepaint, bool allowForce)
	{
		OriginalPaintTraverse(g_VGuiPanel, panel, forceRepaint, allowForce);
		static vgui::VPANEL FocusOverlayPanel = 0;
		if (!FocusOverlayPanel && !strcmp(g_VGuiPanel->GetName(panel), "FocusOverlayPanel"))
			FocusOverlayPanel = panel;
		if (FocusOverlayPanel != panel || !g_EngineClient->IsInGame() || g_EngineClient->IsTakingScreenshot() || !g_LocalPlayer)
			return;

		for (auto entity : *g_EntityList)
		{
			if (!entity || entity == g_LocalPlayer || entity->GetClientClass()->m_ClassID != CCSPlayer)
				continue;
			auto target = (C_BasePlayer*)entity;
			if (target->IsDormant() || !target->IsAlive())
				continue;
			auto screen = g_EngineClient->GetScreenSize();
			auto view_matrix = g_EngineClient->WorldToScreenMatrix();
			for (int i = 0; i < SPINE_END; ++i)
			{
				Vector2 out;
				if (WorldToScreen(view_matrix, target->GetHitboxPos(i), screen, out))
				{
					static auto font = g_VGuiSurface->CreateFont_();
					static auto once = g_VGuiSurface->SetFontGlyphSet(font, "Arial", 12, 700, 0, 0, FONTFLAG_DROPSHADOW);
					auto str = std::to_wstring(i);
					int tw, th;
					g_VGuiSurface->GetTextSize(font, str.c_str(), tw, th);
					g_VGuiSurface->DrawSetTextFont(302);
					g_VGuiSurface->DrawSetTextColor(Color::White);
					g_VGuiSurface->DrawSetTextPos((int)out.x - tw / 2, (int)out.y - th);
					g_VGuiSurface->DrawPrintText(str.c_str(), str.length());
				}
			}
		}

		if (g_Options.esp_enabled)
		for (auto i = 1; i <= g_EntityList->GetHighestEntityIndex(); ++i)
		{
			auto entity = C_BasePlayer::GetPlayerByIndex(i);
			if (!entity || entity == g_LocalPlayer)
				continue;
			if (i < 65 && !entity->IsDormant() && entity->IsAlive())
			{
				// Begin will calculate player screen coordinate, bounding box, etc
				// If it returns false it means the player is not inside the screen
				// or is an ally (and team check is enabled)
				if (Visuals::Player::Begin(entity)) {
					if (g_Options.esp_player_snaplines) Visuals::Player::RenderSnapline();
					if (g_Options.esp_player_boxes)     Visuals::Player::RenderBox();
					if (g_Options.esp_player_weapons)   Visuals::Player::RenderWeapon();
					if (g_Options.esp_player_names)     Visuals::Player::RenderName();
					if (g_Options.esp_player_health)    Visuals::Player::RenderHealth();
					if (g_Options.esp_player_armour)    Visuals::Player::RenderArmour();
				}
			}
			else if (g_Options.esp_dropped_weapons && entity->IsWeapon())
				Visuals::Misc::RenderWeapon((C_BaseCombatWeapon*)entity);
			else if (g_Options.esp_defuse_kit && entity->IsDefuseKit())
				Visuals::Misc::RenderDefuseKit(entity);
			else if (entity->IsPlantedC4() && g_Options.esp_planted_c4)
				Visuals::Misc::RenderPlantedC4(entity);
		}
		if (g_Options.esp_crosshair)
			Visuals::Misc::RenderCrosshair();
	}

	void __stdcall hkPlaySound(const char* name)
	{
		OriginalPlaySound(g_VGuiSurface, name);
		// Auto Accept
		if (strstr(name, "UI/competitive_accept_beep.wav"))
		{
			static auto fnAccept = (void(*)())Utils::PatternScan(modules::client, "55 8B EC 83 E4 F8 83 EC 08 56 8B 35 ? ? ? ? 57 83 BE");
			fnAccept();
			//This will flash the CSGO window on the taskbar
			//so we know a game was found (you cant hear the beep sometimes cause it auto-accepts too fast)
			//FLASHWINFO fi;
			//fi.cbSize = sizeof(FLASHWINFO);
			//fi.hwnd = g_win_input.GetMainWindow();
			//fi.dwFlags = FLASHW_ALL | FLASHW_TIMERNOFG;
			//fi.uCount = 0;
			//fi.dwTimeout = 0;
			//FlashWindowEx(&fi);
		}
	}

	int __stdcall hkDoPostScreenEffects(int a1)
	{
		if (g_LocalPlayer && g_Options.glow_enabled)
			Glow::Run();
		return OriginalDoPostScreenEffects(g_ClientMode, a1);
	}

	void __stdcall hkFrameStageNotify(ClientFrameStage_t stage)
	{
		Skins::OnFrameStageNotify(stage);
		if (stage == FRAME_RENDER_START && g_LocalPlayer && g_LocalPlayer->IsAlive())
		{
			auto m_aimPunchAngle = g_LocalPlayer->m_aimPunchAngle;
			auto m_viewPunchAngle = g_LocalPlayer->m_viewPunchAngle;
			g_LocalPlayer->m_aimPunchAngle = Vector3::Zero;
			g_LocalPlayer->m_viewPunchAngle = Vector3::Zero;
			OriginalFrameStageNotify(g_CHLClient, stage);
			g_LocalPlayer->m_aimPunchAngle = m_aimPunchAngle;
			g_LocalPlayer->m_viewPunchAngle = m_viewPunchAngle;
			return;
		}
		OriginalFrameStageNotify(g_CHLClient, stage);
	}

	void __stdcall hkOverrideView(CViewSetup* vsView)
	{
		if (g_EngineClient->IsInGame() && vsView)
			Visuals::Misc::ThirdPerson();
		OriginalOverrideView(g_ClientMode, vsView);
	}

	void __stdcall hkDrawModelExecute(IMatRenderContext* ctx, const DrawModelState_t& state, const ModelRenderInfo_t& pInfo, matrix3x4_t* pCustomBoneToWorld)
	{
		g_chams.OnDrawModelExecute(ctx, state, pInfo, pCustomBoneToWorld);

		OriginalDrawModelExecute(g_MdlRender, ctx, state, pInfo, pCustomBoneToWorld);

		g_MdlRender->ForcedMaterialOverride(nullptr);
	}

	bool __fastcall hkSvCheatsGetBool(void* pConVar, void*)
	{
		static auto dwCAM_Think = Utils::PatternScan(modules::client, "85 C0 75 30 38 86");
		return _ReturnAddress() == dwCAM_Think ? true : OriginalSvCheatsGetBool(pConVar);
	}

	bool __stdcall hkFireEvent(IGameEvent* pEvent)
	{
		if (!strcmp(pEvent->GetName(), "player_death") && g_EngineClient->GetPlayerForUserID(pEvent->GetInt("attacker")) == g_EngineClient->GetLocalPlayer())
		{
			auto& weapon = g_LocalPlayer->m_hActiveWeapon;
			if (weapon && weapon->IsWeapon())
			{
				auto& skin_data = g_Options.skins.m_items[weapon->m_Item2.m_iItemDefinitionIndex];
				if (skin_data.enabled && skin_data.stat_trak)
				{
					weapon->m_nFallbackStatTrak = ++skin_data.stat_trak;
					weapon->GetClientNetworkable()->PostDataUpdate(0);
					weapon->GetClientNetworkable()->OnDataChanged(0);
				}
			}
			const auto icon_override = g_Options.skins.get_icon_override(pEvent->GetString("weapon"));
			if (icon_override)
				pEvent->SetString("weapon", icon_override);
		}
		return OriginalFireEvent(g_GameEvents, pEvent);
	}

	int random_sequence(int low, int high)
	{
		return rand() % (high - low + 1) + low;
	}

	int fix_animation(const char* model, const int sequence)
	{
		enum ESequence
		{
			SEQUENCE_DEFAULT_DRAW = 0,
			SEQUENCE_DEFAULT_IDLE1 = 1,
			SEQUENCE_DEFAULT_IDLE2 = 2,
			SEQUENCE_DEFAULT_LIGHT_MISS1 = 3,
			SEQUENCE_DEFAULT_LIGHT_MISS2 = 4,
			SEQUENCE_DEFAULT_HEAVY_MISS1 = 9,
			SEQUENCE_DEFAULT_HEAVY_HIT1 = 10,
			SEQUENCE_DEFAULT_HEAVY_BACKSTAB = 11,
			SEQUENCE_DEFAULT_LOOKAT01 = 12,
			SEQUENCE_BUTTERFLY_DRAW = 0,
			SEQUENCE_BUTTERFLY_DRAW2 = 1,
			SEQUENCE_BUTTERFLY_LOOKAT01 = 13,
			SEQUENCE_BUTTERFLY_LOOKAT03 = 15,
			SEQUENCE_FALCHION_IDLE1 = 1,
			SEQUENCE_FALCHION_HEAVY_MISS1 = 8,
			SEQUENCE_FALCHION_HEAVY_MISS1_NOFLIP = 9,
			SEQUENCE_FALCHION_LOOKAT01 = 12,
			SEQUENCE_FALCHION_LOOKAT02 = 13,
			SEQUENCE_DAGGERS_IDLE1 = 1,
			SEQUENCE_DAGGERS_LIGHT_MISS1 = 2,
			SEQUENCE_DAGGERS_LIGHT_MISS5 = 6,
			SEQUENCE_DAGGERS_HEAVY_MISS2 = 11,
			SEQUENCE_DAGGERS_HEAVY_MISS1 = 12,
			SEQUENCE_BOWIE_IDLE1 = 1,
		};
		if (strstr(model, "models/weapons/v_knife_butterfly.mdl"))
		switch (sequence)
		{
		case SEQUENCE_DEFAULT_DRAW:
			return random_sequence(SEQUENCE_BUTTERFLY_DRAW, SEQUENCE_BUTTERFLY_DRAW2);
		case SEQUENCE_DEFAULT_LOOKAT01:
			return random_sequence(SEQUENCE_BUTTERFLY_LOOKAT01, SEQUENCE_BUTTERFLY_LOOKAT03);
		default:
			return sequence + 1;
		}
		if (strstr(model, "models/weapons/v_knife_falchion_advanced.mdl"))
		switch (sequence)
		{
		case SEQUENCE_DEFAULT_IDLE2:
			return SEQUENCE_FALCHION_IDLE1;
		case SEQUENCE_DEFAULT_HEAVY_MISS1:
			return random_sequence(SEQUENCE_FALCHION_HEAVY_MISS1, SEQUENCE_FALCHION_HEAVY_MISS1_NOFLIP);
		case SEQUENCE_DEFAULT_LOOKAT01:
			return random_sequence(SEQUENCE_FALCHION_LOOKAT01, SEQUENCE_FALCHION_LOOKAT02);
		case SEQUENCE_DEFAULT_DRAW:
		case SEQUENCE_DEFAULT_IDLE1:
			return sequence;
		default:
			return sequence - 1;
		}
		if (strstr(model, "models/weapons/v_knife_push.mdl"))
		switch (sequence)
		{
		case SEQUENCE_DEFAULT_IDLE2:
			return SEQUENCE_DAGGERS_IDLE1;
		case SEQUENCE_DEFAULT_LIGHT_MISS1:
		case SEQUENCE_DEFAULT_LIGHT_MISS2:
			return random_sequence(SEQUENCE_DAGGERS_LIGHT_MISS1, SEQUENCE_DAGGERS_LIGHT_MISS5);
		case SEQUENCE_DEFAULT_HEAVY_MISS1:
			return random_sequence(SEQUENCE_DAGGERS_HEAVY_MISS2, SEQUENCE_DAGGERS_HEAVY_MISS1);
		case SEQUENCE_DEFAULT_HEAVY_HIT1:
		case SEQUENCE_DEFAULT_HEAVY_BACKSTAB:
		case SEQUENCE_DEFAULT_LOOKAT01:
			return sequence + 3;
		case SEQUENCE_DEFAULT_DRAW:
		case SEQUENCE_DEFAULT_IDLE1:
			return sequence;
		default:
			return sequence + 2;
		}
		if (strstr(model, "models/weapons/v_knife_survival_bowie.mdl"))
		switch (sequence)
		{
		case SEQUENCE_DEFAULT_DRAW:
		case SEQUENCE_DEFAULT_IDLE1:
			return sequence;
		case SEQUENCE_DEFAULT_IDLE2:
			return SEQUENCE_BOWIE_IDLE1;
		default:
			return sequence - 1;
		}
		return sequence;
	}

	void hkRecvProxy(const CRecvProxyData* pData, void* entity, void* output)
	{
		const auto local = (C_BasePlayer*)g_EntityList->GetClientEntity(g_EngineClient->GetLocalPlayer());
		if (local && local->IsAlive())
		{
			const auto proxy_data = const_cast<CRecvProxyData*>(pData);
			const auto view_model = static_cast<C_BaseViewModel*>(entity);
			if (view_model && view_model->m_hOwner && view_model->m_hOwner.IsValid())
			{
				const auto owner = (C_BasePlayer*)g_EntityList->GetClientEntityFromHandle(view_model->m_hOwner);
				if (owner == g_EntityList->GetClientEntity(g_EngineClient->GetLocalPlayer()))
				{
					const auto view_model_weapon_handle = view_model->m_hWeapon;
					if (view_model_weapon_handle.IsValid())
					{
						const auto view_model_weapon = (C_BaseAttributableItem*)g_EntityList->GetClientEntityFromHandle(view_model_weapon_handle);
						if (view_model_weapon && k_weapon_info.count(view_model_weapon->m_Item2.m_iItemDefinitionIndex))
						{
							auto original_sequence = proxy_data->m_Value.m_Int;
							const auto override_model = k_weapon_info.at(view_model_weapon->m_Item2.m_iItemDefinitionIndex).model;
							proxy_data->m_Value.m_Int = fix_animation(override_model, proxy_data->m_Value.m_Int);
						}
					}
				}
			}
		}
		OriginalRecvProxy(pData, entity, output);
	}

	void Initialize()
	{
		OriginalWndProc = (WNDPROC)SetWindowLongPtr(g_hwnd, GWLP_WNDPROC, (LONG_PTR)&hkWndProc);

		VmtHook(g_D3DDevice9, index::EndScene, &hkEndScene, OriginalEndScene);
		VmtHook(g_D3DDevice9, index::Reset, &hkReset, OriginalReset);
		VmtHook(g_CHLClient, index::FrameStageNotify, &hkFrameStageNotify, OriginalFrameStageNotify);
		//VmtHook(g_CHLClient, index::CreateMove, &hkCreateMove, OriginalCreateMove);
		VmtHook(g_VGuiPanel, index::PaintTraverse, &hkPaintTraverse, OriginalPaintTraverse);
		VmtHook(g_VGuiSurface, index::PlaySound, &hkPlaySound, OriginalPlaySound);
		VmtHook(g_MdlRender, index::DrawModelExecute, &hkDrawModelExecute, OriginalDrawModelExecute);

		VmtHook(g_ClientMode, index::CreateMove2, &hkCreateMove2, OriginalCreateMove2);

		VmtHook(g_ClientMode, index::DoPostScreenSpaceEffects, &hkDoPostScreenEffects, OriginalDoPostScreenEffects);
		VmtHook(g_ClientMode, index::OverrideView, &hkOverrideView, OriginalOverrideView);
		VmtHook(g_CVar->FindVar("sv_cheats"), index::SvCheatsGetBool, &hkSvCheatsGetBool, OriginalSvCheatsGetBool);

		Visuals::CreateFonts();
	}

	void Shutdown()
	{
		SetWindowLongPtr(g_hwnd, GWLP_WNDPROC, (LONG_PTR)OriginalWndProc);

		VmtUnHook(g_D3DDevice9, index::EndScene, OriginalEndScene);
		VmtUnHook(g_D3DDevice9, index::Reset, OriginalReset);
		VmtUnHook(g_CHLClient, index::FrameStageNotify, OriginalFrameStageNotify);
		//VmtUnHook(g_CHLClient, index::CreateMove, OriginalCreateMove);
		VmtUnHook(g_VGuiPanel, index::PaintTraverse, OriginalPaintTraverse);
		VmtUnHook(g_VGuiSurface, index::PlaySound, OriginalPlaySound);
		VmtUnHook(g_MdlRender, index::DrawModelExecute, OriginalDrawModelExecute);
		VmtUnHook(g_ClientMode, index::CreateMove2, OriginalCreateMove2);
		VmtUnHook(g_ClientMode, index::DoPostScreenSpaceEffects, OriginalDoPostScreenEffects);
		VmtUnHook(g_ClientMode, index::OverrideView, OriginalOverrideView);
		VmtUnHook(g_CVar->FindVar("sv_cheats"), index::SvCheatsGetBool, OriginalSvCheatsGetBool);

		Glow::Shutdown();

		Visuals::DestroyFonts();
	}

}
