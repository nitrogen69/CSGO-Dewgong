#include "bhop.hpp"

#include "../valve_sdk/csgostructs.hpp"

void BunnyHop::OnCreateMove(CUserCmd* cmd)
{
	if (~g_LocalPlayer->m_fFlags & FL_ONGROUND)
		cmd->buttons &= ~IN_JUMP;
}