#pragma once
#include <Windows.h>
#include <dllhack.h>

#include "misc/Enums.hpp"
#include "math/VMatrix.hpp"
#include "math/QAngle.hpp"
#include "math/Vector.hpp"
#include "misc/Studio.hpp"

#include "interfaces/IAppSystem.hpp"
#include "interfaces/IClientEntity.hpp"
#include "interfaces/IBaseClientDll.hpp"
#include "interfaces/IClientEntityList.hpp"
#include "interfaces/IClientMode.hpp"
#include "interfaces/IConVar.hpp"
#include "interfaces/ICvar.hpp"
#include "interfaces/IEngineTrace.hpp"
#include "interfaces/IVEngineClient.hpp"
#include "interfaces/IVDebugOverlay.hpp"
#include "interfaces/ISurface.hpp"
#include "interfaces/CInput.hpp"
#include "interfaces/IVModelInfoClient.hpp"
#include "interfaces/IVModelRender.hpp"
#include "interfaces/IRenderView.hpp"
#include "interfaces/IGameEventmanager.hpp"
#include "interfaces/IMaterialSystem.hpp"
#include "interfaces/IMoveHelper.hpp"
#include "interfaces/IMDLCache.hpp"
#include "interfaces/IPrediction.hpp"
#include "interfaces/IPanel.hpp"
#include "interfaces/IEngineSound.hpp"
#include "interfaces/IViewRender.hpp"
#include "interfaces/CClientState.hpp"
#include "interfaces/IPhysics.hpp"
#include "interfaces/ILocalize.hpp"

#include "misc/Convar.hpp"
#include "misc/CUserCmd.hpp"
#include "misc/glow_outline_effect.hpp"

#include "netvars.hpp"
#include <xorstr.h>

struct IDirect3DDevice9;

namespace Interfaces
{
	void Initialize();
}

namespace modules
{
	inline HMODULE engine;
	inline HMODULE client;
	inline HMODULE vstdlib;
	inline HMODULE vguimatsurface;
	inline HMODULE vgui2;
	inline HMODULE materialsystem;
	inline HMODULE datacache;
	inline HMODULE vphysics;
	inline HMODULE localize;
	inline HMODULE dx9api;
	inline HMODULE tier0;
}

inline IVEngineClient*       g_EngineClient = nullptr;
inline IBaseClientDLL*       g_CHLClient = nullptr;
inline IClientEntityList*    g_EntityList = nullptr;
inline CGlobalVarsBase*      g_GlobalVars = nullptr;
inline IEngineTrace*         g_EngineTrace = nullptr;
inline ICvar*                g_CVar = nullptr;
inline IPanel*               g_VGuiPanel = nullptr;
inline IClientMode*          g_ClientMode = nullptr;
inline IVDebugOverlay*       g_DebugOverlay = nullptr;
inline ISurface*             g_VGuiSurface = nullptr;
inline CInput*               g_Input = nullptr;
inline IVModelInfoClient*    g_MdlInfo = nullptr;
inline IVModelRender*        g_MdlRender = nullptr;
inline IVRenderView*         g_RenderView = nullptr;
inline IMaterialSystem*      g_MatSystem = nullptr;
inline IGameEventManager2*   g_GameEvents = nullptr;
inline IMoveHelper*          g_MoveHelper = nullptr;
inline IMDLCache*            g_MdlCache = nullptr;
inline IPrediction*          g_Prediction = nullptr;
inline CGameMovement*        g_GameMovement = nullptr;
inline IEngineSound*         g_EngineSound = nullptr;
inline CGlowObjectManager*   g_GlowObjManager = nullptr;
inline IViewRender*          g_ViewRender = nullptr;
inline IDirect3DDevice9*     g_D3DDevice9 = nullptr;
inline CClientState*         g_ClientState = nullptr;
inline IPhysicsSurfaceProps* g_PhysSurface = nullptr;
inline ILocalize*            g_Localize = nullptr;
inline HWND                  g_hwnd = nullptr;


template<typename... Args>
void ConMsg(const char* pMsg, Args&&... args)
{
	static auto import = (void(*)(const char*, ...))GetProcAddress(modules::tier0, xstr("?ConMsg@@YAXPBDZZ"));
	return import(pMsg, args...);
}
template<typename... Args>
void ConColorMsg(Color color, const char* pMsg, Args&&... args)
{
	static auto import = (void(*)(const Color&, const char*, ...))GetProcAddress(modules::tier0, xstr("?ConColorMsg@@YAXABVColor@@PBDZZ"));
	return import(color, pMsg, args...);
}

#include "misc/EHandle.hpp"

class C_LocalPlayer
{
	C_BasePlayer** player;
public:
	C_LocalPlayer(C_BasePlayer** player = nullptr) : player(player) {  }
	operator bool() const { return *player; }
	operator C_BasePlayer*() const { return *player; }
	C_BasePlayer* operator->() const { return *player; }
	bool operator==(const void* ptr) const { return ptr == *player; }
	C_BasePlayer* operator+() const { return *player; }
};

inline C_LocalPlayer g_LocalPlayer;