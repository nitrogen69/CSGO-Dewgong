#ifndef _CWININPUT_H
#define _CWININPUT_H
#pragma once
#include <Windows.h>
#include <math_vectors.h>

using MouseKey = unsigned;
using KeyState = unsigned;

enum EMouseKey : MouseKey
{
	MouseKey_LButton,
	MouseKey_RButton,
	MouseKey_MButton,
	MouseKey_Count
};

enum EFKeyState : KeyState
{
	KeyState_Up = 0 << 0,
	KeyState_Down = 1 << 0,
	KeyState_Pressed = 1 << 1,
	KeyState_Released = 1 << 2,
};

struct IMenuInput
{
	virtual ~IMenuInput() {  }

	virtual KeyState GetKeyState(int key) const = 0;
	bool IsKeyDown(int key) const { return GetKeyState(key) & KeyState_Down; }
	bool IsKeyPressed(int key) const { return GetKeyState(key) & KeyState_Pressed; }
	bool IsKeyReleased(int key) const { return GetKeyState(key) & KeyState_Released; }

	virtual KeyState GetMouseKeyState(MouseKey key) const = 0;
	bool IsMouseKeyDown(MouseKey key) const { return GetMouseKeyState(key) & KeyState_Down; }
	bool IsMouseKeyPressed(MouseKey key) const { return GetMouseKeyState(key) & KeyState_Pressed; }
	bool IsMouseKeyReleased(MouseKey key) const { return GetMouseKeyState(key) & KeyState_Released; }

	virtual Vector2 GetPressPosition(MouseKey key) const = 0;
	virtual Vector2 GetReleasePosition(MouseKey key) const = 0;

	PropertyGetAbstract(float, FrameRate);
	PropertyGetAbstract(Vector2, MouseDelta);
	PropertyGetAbstract(Vector2, MouseLastPosition);
	PropertyGetAbstract(Vector2, MousePosition);
	PropertyGetAbstract(int, MouseWheelDelta);
	PropertyGetAbstract(int, MouseWheel);
	PropertyGetAbstract(wchar_t, LastChar);
	PropertyGetAbstract(float, DeltaTime);
};

struct CWinInput final : IMenuInput
{
	static void Update(UINT msg, WPARAM wParam, LPARAM lParam);
	static void EndFrame();
	KeyState GetKeyState(int key) const final;
	KeyState GetMouseKeyState(MouseKey key) const final;
	Vector2 GetMousePosition() const final;
	Vector2 GetMouseDelta() const final;
	Vector2 GetMouseLastPosition() const final;
	int GetMouseWheelDelta() const final;
	int GetMouseWheel() const final;
	wchar_t GetLastChar() const final;
	float GetDeltaTime() const final;
	float GetFrameRate() const final;
	Vector2 GetPressPosition(MouseKey key) const final;
	Vector2 GetReleasePosition(MouseKey key) const final;
	PropertyGet(float, FrameRate);
	PropertyGet(Vector2, MouseDelta);
	PropertyGet(Vector2, MousePosition);
	PropertyGet(int, MouseWheelDelta);
	PropertyGet(int, MouseWheel);
	PropertyGet(wchar_t, LastChar);
	PropertyGet(float, DeltaTime);
};

inline CWinInput g_win_input;

#endif // !_CINPUT_H