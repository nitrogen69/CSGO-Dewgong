#pragma once

#include "../Misc/IHandleEntity.hpp"

class IClientNetworkable;
class IClientEntity;

struct EntityIterator;

class IClientEntityList
{
public:
    virtual IClientNetworkable*   GetClientNetworkable(int entnum) = 0;
    virtual void*                 vtablepad0x1() = 0;
    virtual void*                 vtablepad0x2() = 0;
    virtual IClientEntity*        GetClientEntity(int entNum) = 0;
    virtual IClientEntity*        GetClientEntityFromHandle(CBaseHandle hEnt) = 0;
    virtual int                   NumberOfEntities(bool bIncludeNonNetworkable) = 0;
    virtual int                   GetHighestEntityIndex() = 0;
    virtual void                  SetMaxEntities(int maxEnts) = 0;
    virtual int                   GetMaxEntities() = 0;
	EntityIterator begin();
	EntityIterator end();
};

struct EntityIterator
{
	IClientEntityList* el;
	int index;
	IClientEntity* operator*() const { return el->GetClientEntity(index); }
	//IClientEntity** operator->() const { return *this; }
	EntityIterator& operator++() { return ++index, *this; }
	EntityIterator operator++(int) { return { el, index++ }; }
	bool operator==(const EntityIterator& e) const { return index == e.index; }
	bool operator!=(const EntityIterator& e) const { return !(*this == e); }
};

inline EntityIterator IClientEntityList::begin() { return { this, 1 }; }

inline EntityIterator IClientEntityList::end() { return { this, GetHighestEntityIndex() + 1 }; }
