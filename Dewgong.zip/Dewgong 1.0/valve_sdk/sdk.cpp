#include "sdk.hpp"

#include "../helpers/utils.hpp"

#include <dllhack.h>
#include <Windows.h>
#include <sstream>

#include <xorstr.h>
#include <d3d9.h>

// Ugly macros ugh
#define STRINGIFY_IMPL(s) #s
#define STRINGIFY(s) STRINGIFY_IMPL(s)
#define PRINT_INTERFACE(name) Utils::ConsolePrint("%-20s: %p\n", xstr(STRINGIFY(name)), name)

using namespace modules;

CreateInterfaceFn GetFactory(HMODULE module) { return CreateInterfaceFn(GetProcAddress(module, xstr("CreateInterface"))); }

template<typename Interface>
Interface* GetInterface(CreateInterfaceFn f, const char* interfaceName)
{
	for (size_t i = 0; i < 100; i++)
	{
		std::stringstream ss;
		ss << interfaceName << (i < 10 ? "00" : "0") << i;
		if (auto result = (Interface*)f(ss.str().c_str(), nullptr))
			return result;
	}
	throw std::runtime_error(std::string(xstr("GetInterface Failed to GetOffset interface: ")) + interfaceName);
}

void Interfaces::Initialize()
{
	engine = GetModuleHandleA(xstr("engine.dll"));
	client = GetModuleHandleA(xstr("client_panorama.dll"));
	vstdlib = GetModuleHandleA(xstr("vstdlib.dll"));
	vguimatsurface = GetModuleHandleA(xstr("vguimatsurface.dll"));
	vgui2 = GetModuleHandleA(xstr("vgui2.dll"));
	materialsystem = GetModuleHandleA(xstr("materialsystem.dll"));
	datacache = GetModuleHandleA(xstr("datacache.dll"));
	vphysics = GetModuleHandleA(xstr("vphysics.dll"));
	localize = GetModuleHandleA(xstr("localize.dll"));
	dx9api = GetModuleHandleA(xstr("shaderapidx9.dll"));
	tier0 = GetModuleHandleA(xstr("tier0.dll"));

	auto engineFactory = GetFactory(engine);
	auto clientFactory = GetFactory(client);
	auto valveStdFactory = GetFactory(vstdlib);
	auto vguiFactory = GetFactory(vguimatsurface);
	auto vgui2Factory = GetFactory(vgui2);
	auto matSysFactory = GetFactory(materialsystem);
	auto dataCacheFactory = GetFactory(datacache);
	auto vphysicsFactory = GetFactory(vphysics);
	auto localizeFactory = GetFactory(localize);

	g_CHLClient = GetInterface<IBaseClientDLL>(clientFactory, xstr("VClient"));
	g_EntityList = GetInterface<IClientEntityList>(clientFactory, xstr("VClientEntityList"));
	g_Prediction = GetInterface<IPrediction>(clientFactory, xstr("VClientPrediction"));
	g_GameMovement = GetInterface<CGameMovement>(clientFactory, xstr("GameMovement"));
	g_MdlCache = GetInterface<IMDLCache>(dataCacheFactory, xstr("MDLCache"));
	g_EngineClient = GetInterface<IVEngineClient>(engineFactory, xstr("VEngineClient"));
	g_MdlInfo = GetInterface<IVModelInfoClient>(engineFactory, xstr("VModelInfoClient"));
	g_MdlRender = GetInterface<IVModelRender>(engineFactory, xstr("VEngineModel"));
	g_RenderView = GetInterface<IVRenderView>(engineFactory, xstr("VEngineRenderView"));
	g_EngineTrace = GetInterface<IEngineTrace>(engineFactory, xstr("EngineTraceClient"));
	g_DebugOverlay = GetInterface<IVDebugOverlay>(engineFactory, xstr("VDebugOverlay"));
	g_GameEvents = GetInterface<IGameEventManager2>(engineFactory, xstr("GAMEEVENTSMANAGER"));
	g_EngineSound = GetInterface<IEngineSound>(engineFactory, xstr("IEngineSoundClient"));
	g_MatSystem = GetInterface<IMaterialSystem>(matSysFactory, xstr("VMaterialSystem"));
	g_CVar = GetInterface<ICvar>(valveStdFactory, xstr("VEngineCvar"));
	g_VGuiPanel = GetInterface<IPanel>(vgui2Factory, xstr("VGUI_Panel"));
	g_VGuiSurface = GetInterface<ISurface>(vguiFactory, xstr("VGUI_Surface"));
	g_PhysSurface = GetInterface<IPhysicsSurfaceProps>(vphysicsFactory, xstr("VPhysicsSurfaceProps"));
	g_Localize = GetInterface<ILocalize>(localizeFactory, xstr("Localize_"));

	g_GlobalVars = **(CGlobalVarsBase***)(Utils::PatternScan(client, xstr("A1 ? ? ? ? 5E 8B 40 10")) + 1);
	g_ClientMode = *(IClientMode**)(Utils::PatternScan(client, xstr("A1 ? ? ? ? 8B 80 ? ? ? ? 5D")) + 1);
	g_Input = *(CInput**)(Utils::PatternScan(client, xstr("B9 ? ? ? ? 8B 40 38 FF D0 84 C0 0F 85")) + 1);
	g_MoveHelper = **(IMoveHelper***)(Utils::PatternScan(client, xstr("8B 0D ? ? ? ? 8B 45 ? 51 8B D4 89 02 8B 01")) + 2);
	g_GlowObjManager = *(CGlowObjectManager**)(Utils::PatternScan(client, xstr("0F 11 05 ? ? ? ? 83 C8 01")) + 3);
	g_ViewRender = *(IViewRender**)(Utils::PatternScan(client, xstr("A1 ? ? ? ? B9 ? ? ? ? C7 05 ? ? ? ? ? ? ? ? FF 10")) + 1);
	g_D3DDevice9 = **(IDirect3DDevice9***)(Utils::PatternScan(dx9api, xstr("A1 ? ? ? ? 50 8B 08 FF 51 0C")) + 1);
	g_ClientState = **(CClientState***)(Utils::PatternScan(engine, xstr("A1 ? ? ? ? 8B 80 ? ? ? ? C3")) + 1);

	g_LocalPlayer = *(C_LocalPlayer*)(Utils::PatternScan(client, xstr("8B 0D ? ? ? ? 83 FF FF 74 07")) + 2);

	D3DDEVICE_CREATION_PARAMETERS cParam;
	g_D3DDevice9->GetCreationParameters(&cParam);
	g_hwnd = cParam.hFocusWindow;
}