#pragma once
#include "../valve_sdk/sdk.hpp"
#include "../datamap.hpp"

namespace Utils
{
	unsigned int FindInDataMap(datamap_t * pMap, const char * name);
	BYTE* PatternScan(void* module, const char* signature);
	void SetClantag(const char* tag);
	void SetName(const char* name);
	void RankRevealAll();
}
