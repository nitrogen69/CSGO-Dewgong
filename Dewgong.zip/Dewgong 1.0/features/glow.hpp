#pragma once

struct Glow
{
	static void Run();
	static void Shutdown();
};