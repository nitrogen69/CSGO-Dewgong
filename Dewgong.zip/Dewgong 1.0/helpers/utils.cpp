#include "utils.hpp"

#include <Windows.h>
#include <cstdio>

#include "../valve_sdk/csgostructs.hpp"
#include "math.hpp"

#include <dllhack.h>
#include <xorstr.h>

HANDLE _out = NULL, _old_out = NULL;
HANDLE _err = NULL, _old_err = NULL;
HANDLE _in = NULL, _old_in = NULL;

namespace Utils
{
	unsigned int FindInDataMap(datamap_t *pMap, const char *name)
	{
		while (pMap)
		{
			for (int i = 0; i < pMap->dataNumFields; i++)
			{
				if (!pMap->dataDesc[i].fieldName)
					continue;
				if (!strcmp(name, pMap->dataDesc[i].fieldName))
					return pMap->dataDesc[i].fieldOffset[TD_OFFSET_NORMAL];
				if (pMap->dataDesc[i].fieldType == FIELD_EMBEDDED && pMap->dataDesc[i].td)
					if (auto offset = FindInDataMap(pMap->dataDesc[i].td, name))
						return offset;
			}
			pMap = pMap->baseMap;
		}
		return 0;
	}

	BYTE* PatternScan(void* module, const char* signature)
	{
		return ::PatternScan(HMODULE(module), signature);
	}

    void SetClantag(const char* tag)
    {
        static auto fnClantagChanged = (int(__fastcall*)(const char*, const char*))::PatternScan(modules::engine, xstr("53 56 57 8B DA 8B F9 FF 15"));
        fnClantagChanged(tag, tag);
    }

    void SetName(const char* name)
    {
        static auto nameConvar = g_CVar->FindVar("name");
        nameConvar->m_fnChangeCallbacks.m_Size = 0;

        // Fix so we can change names how many times we want
        // This code will only run once because of `static`
        static auto do_once = (nameConvar->SetValue("\n���"), true);

        nameConvar->SetValue(name);
    }

    void RankRevealAll()
    {
		return;
		using ServerRankRevealAll = char(__cdecl*)(int*);
		static auto fnServerRankRevealAll = ::PatternScan(modules::client, xstr("55 8B EC 8B 0D ? ? ? ? 68"));
		int v[3] = { 0,0,0 };
		reinterpret_cast<ServerRankRevealAll>(fnServerRankRevealAll)(v);
    }
}