#include <Windows.h>
#include "helpers/utils.hpp"

#include "valve_sdk/sdk.hpp"

#include "hooks.hpp"
#include "menu.hpp"
#include "features/chams.hpp"

//Made by sadm1234

HMODULE hModule;

DWORD WINAPI Quitter(LPVOID)
{
	while (GetModuleHandleA("engine.dll") && !GetAsyncKeyState(VK_F4))
	{
		if (GetAsyncKeyState(VK_INSERT))
		{
			g_menu.Toggle();
			Sleep(400);
		}

		Sleep(100);
	}
	//if (MessageBoxA(NULL, "Quit?", "", MB_YESNO) == IDNO) return Quitter(nullptr);
	Hooks::Shutdown();
	Beep(523, 1000);
	FreeLibraryAndExitThread(hModule, 0);
}

void OnDllAttach()
{
	Interfaces::Initialize();
	g_netvar_sys.Initialize();
	g_menu.Initialize();
	g_chams.Initialize();

	Hooks::Initialize();


	//g_win_input.RegisterHotkey(VK_INSERT, []() { g_menu.Toggle(); });

	//g_CVar->FindVar("crosshair")->SetValue(true);

#ifdef _DEBUG
	CreateThread(0, 0, &Quitter, NULL, 0, NULL);
#endif

}

BOOL WINAPI DllMain(HINSTANCE hinstDll, DWORD fdwReason, LPVOID lpvReserved)
{
	hModule = hinstDll;
	if (fdwReason == DLL_PROCESS_ATTACH)
		OnDllAttach();
	return TRUE;
}