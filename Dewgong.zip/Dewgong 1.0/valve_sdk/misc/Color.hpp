#pragma once

struct Color
{
	static Color Black;
	static Color White;
	static Color Red;
	static Color Green;
	static Color Blue;

	union { unsigned long color; unsigned char raw[4]; struct { unsigned char b, g, r, a; }; };

	Color() : color(0) {  }
	Color(int r, int g, int b, int a = 0xFF) : b(b), g(g), r(r), a(a) {  }
	Color(float r, float g, float b, float a = 1) : Color(int(r * 255), int(g * 255), int(b * 255), int(a * 255)) {  }
	explicit Color(const float* rgb) : Color(rgb[0], rgb[1], rgb[2], 1.f) {  }
	explicit Color(unsigned long argb) : color((argb & 0x00FFFFFF) << 1 * 8 | (argb & 0xFF000000) >> 3 * 8) {  }

	unsigned char& operator[](int index) { return raw[index]; }
	unsigned char  operator[](int index) const { return raw[index]; }

	void GetColor(int& _r, int& _g, int& _b, int& _a) const
	{
		_r = r;
		_g = g;
		_b = b;
		_a = a;
	}

};