#include <windowsx.h>
#include <list>
#include <numeric>
#include "input.hpp"

Vector2 mouse_delta;
Vector2 mouse_position;
Vector2 mouse_last_position;
Vector2 mouse_press_position[MouseKey_Count];
Vector2 mouse_release_position[MouseKey_Count];
int mouse_wheel_delta = 0;
int mouse_wheel = 0;
KeyState key[0xFF] = {  };
KeyState mouse_key[5] = {  };
wchar_t last_char = 0;
float delta_time = 0;
float previousTime = 0;
size_t samples = 60;
float framerate = 0;
std::list<float> list;

void SetMousePosition(const Vector2& pos)
{
	mouse_last_position = mouse_position;
	mouse_delta = pos - mouse_position;
	mouse_position = pos;
}

void SetMouseWheel(int value)
{
	mouse_wheel_delta = value - mouse_wheel;
	mouse_wheel = value;
}

void UpdateDeltaTime()
{
	auto currentTime = (float)GetTickCount();
	delta_time = (currentTime - previousTime) / 1000.f;
	delta_time = std::min(delta_time, .1f);
	previousTime = currentTime;
}

void UpdateMouseInfo(MouseKey key, KeyState state)
{
	mouse_key[key] = state;
	if (state & KeyState_Pressed)
		mouse_press_position[key] = mouse_position;
	else if (state & KeyState_Released)
		mouse_release_position[key] = mouse_position;
}

void UpdateFrameRate()
{
	list.insert(list.begin(), delta_time);
	if (list.size() > samples)
		list.resize(samples);
	framerate = (float)samples / std::accumulate(list.begin(), list.end(), float(0));
}

void CWinInput::Update(UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch (msg)
	{
		//Mouse Input
	case WM_MOUSEMOVE:
		SetMousePosition({ (float)GET_X_LPARAM(lParam), (float)GET_Y_LPARAM(lParam) });
		break;
	case WM_LBUTTONDOWN:
		UpdateMouseInfo(MouseKey_LButton, KeyState_Down | KeyState_Pressed);
		break;
	case WM_RBUTTONDOWN:
		UpdateMouseInfo(MouseKey_RButton, KeyState_Down | KeyState_Pressed);
		break;
	case WM_MBUTTONDOWN:
		UpdateMouseInfo(MouseKey_MButton, KeyState_Down | KeyState_Pressed);
		break;
	case WM_LBUTTONUP:
		UpdateMouseInfo(MouseKey_LButton, KeyState_Up | KeyState_Released);
		break;
	case WM_RBUTTONUP:
		UpdateMouseInfo(MouseKey_RButton, KeyState_Up | KeyState_Released);
		break;
	case WM_MBUTTONUP:
		UpdateMouseInfo(MouseKey_MButton, KeyState_Up | KeyState_Released);
		break;
	case WM_MOUSEWHEEL:
		SetMouseWheel(mouse_wheel + GET_WHEEL_DELTA_WPARAM(wParam) / WHEEL_DELTA);
		break;
		//Keys Input
	case WM_SYSKEYDOWN:
	case WM_KEYDOWN:
		key[wParam] = KeyState_Down | KeyState_Pressed;
		break;
	case WM_SYSKEYUP:
	case WM_KEYUP:
		key[wParam] = KeyState_Up | KeyState_Released;
		break;
	case WM_CHAR:
		last_char = (wchar_t)wParam;
		break;
	}
}

void CWinInput::EndFrame()
{
	UpdateDeltaTime();
	UpdateFrameRate();
	mouse_delta = Vector2::Zero;
	mouse_wheel_delta = 0;
	last_char = 0;
	for (auto&& key : ::key) key &= ~KeyState_Pressed & ~KeyState_Released;
	for (auto&& key : mouse_key) key &= ~KeyState_Pressed & ~KeyState_Released;
}

KeyState CWinInput::GetKeyState(int key) const
{
	return ::key[key];
}

KeyState CWinInput::GetMouseKeyState(MouseKey key) const
{
	return mouse_key[key];
}

Vector2 CWinInput::GetMousePosition() const
{
	return mouse_position;
}

Vector2 CWinInput::GetMouseDelta() const
{
	return mouse_delta;
}

Vector2 CWinInput::GetMouseLastPosition() const
{
	return mouse_last_position;
}

int CWinInput::GetMouseWheelDelta() const
{
	return mouse_wheel_delta;
}

int CWinInput::GetMouseWheel() const
{
	return mouse_wheel;
}

wchar_t CWinInput::GetLastChar() const
{
	return last_char;
}

float CWinInput::GetDeltaTime() const
{
	return delta_time;
}

float CWinInput::GetFrameRate() const
{
	return framerate;
}

Vector2 CWinInput::GetPressPosition(MouseKey key) const
{
	return mouse_press_position[key];
}

Vector2 CWinInput::GetReleasePosition(MouseKey key) const
{
	return mouse_release_position[key];
}
