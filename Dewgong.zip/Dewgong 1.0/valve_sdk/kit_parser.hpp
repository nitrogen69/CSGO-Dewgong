#pragma once
#include <vector>
struct paint_kit
{
	int id;
	std::string name;
	bool operator<(const paint_kit& other) const { return name < other.name; }
};
extern std::vector<paint_kit> k_skins;
extern std::vector<paint_kit> k_gloves;
extern void initialize_kits();
