#include "aimbot.h"
#include "autowall.h"
#include "helpers/math.hpp"
#include <sysinfoapi.h>
#include <winuser.h>

float RandomFloat(float a, float b)
{
	return a + float(rand()) / float(RAND_MAX) * (b - a);
}
//--------------------------------------------------------------------------------
bool Aimbot::IsRcs()
{
	return g_LocalPlayer->m_iShotsFired >= settings.rcs_start;
}
//--------------------------------------------------------------------------------
float GetRealDistanceFOV(float distance, QAngle angle, CUserCmd* cmd)
{
	Vector aimingAt;
	Math::AngleVectors(cmd->viewangles, aimingAt);
	aimingAt *= distance;
	Vector aimAt;
	Math::AngleVectors(angle, aimAt);
	aimAt *= distance;
	return Vector::Distance(aimingAt, aimAt) / 5;
}
//--------------------------------------------------------------------------------
float Aimbot::GetFovToPlayer(QAngle viewAngle, QAngle aimAngle)
{
	QAngle delta = aimAngle - viewAngle;
	Math::FixAngles(delta);
	return delta.GetMagnitude();
}
//--------------------------------------------------------------------------------
bool Aimbot::IsLineGoesThroughSmoke(Vector vStartPos, Vector vEndPos)
{
	static auto LineGoesThroughSmokeFn = (bool(*)(Vector, Vector))Utils::PatternScan(modules::client, xstr("55 8B EC 83 EC 08 8B 15 ? ? ? ? 0F 57 C0"));
	return LineGoesThroughSmokeFn(vStartPos, vEndPos);
}
//--------------------------------------------------------------------------------
bool Aimbot::IsEnabled(CUserCmd *pCmd)
{
	if (!GetAsyncKeyState(VK_MENU))
		return false;
	if (!g_EngineClient->IsConnected() || !g_LocalPlayer || !g_LocalPlayer->IsAlive())
		return false;
	auto pWeapon = g_LocalPlayer->m_hActiveWeapon;
	if (!pWeapon || !(pWeapon->IsSniper() || pWeapon->IsPistol() || pWeapon->IsRifle()))
		return false;
	//auto weaponData = pWeapon->GetCSWeaponData();
	settings = g_Options.aimbot[pWeapon->m_Item2.m_iItemDefinitionIndex];
	if ((pWeapon->m_Item2.m_iItemDefinitionIndex == WEAPON_AWP || pWeapon->m_Item2.m_iItemDefinitionIndex == WEAPON_SSG08) && settings.only_in_zoom && !g_LocalPlayer->m_bIsScoped)
		return false;
	if (settings.fov == 0 && settings.silent_fov == 0 && !settings.rcs)
		return false;
	if (!pWeapon->HasBullets() || pWeapon->IsReloading())
		return false;
	return true;
}
//--------------------------------------------------------------------------------
float Aimbot::GetSmooth()
{
	float smooth = IsRcs() && settings.rcs_smooth_enabled ? settings.rcs_smooth : settings.smooth;
	if (settings.humanize)
		smooth += RandomFloat(-1, 4);
	return smooth;
}
//--------------------------------------------------------------------------------
void Aimbot::Smooth(QAngle currentAngle, QAngle aimAngle, QAngle& angle)
{
	if (GetSmooth() <= 1)
		return;
	Vector vAimAngle;
	Math::AngleVectors(aimAngle, vAimAngle);
	Vector vCurrentAngle;
	Math::AngleVectors(currentAngle, vCurrentAngle);
	Vector delta = vAimAngle - vCurrentAngle;
	Vector smoothed = vCurrentAngle + delta / GetSmooth();
	Math::VectorAngles(smoothed, angle);
}
//--------------------------------------------------------------------------------
void Aimbot::RCS(QAngle &angle, C_BasePlayer* target)
{
	if (!settings.rcs || !IsRcs())
		return;
	if (settings.rcs_x == 0 && settings.rcs_y == 0)
		return;
	if (target) {
		QAngle punch = g_LocalPlayer->m_aimPunchAngle;
		angle[VPITCH] -= punch[VPITCH] * (settings.rcs_x / 50.f);
		angle[VYAW] -= punch[VYAW] * (settings.rcs_y / 50.f);
	}
	else if (settings.rcs_type == 0) {
		QAngle NewPunch = { CurrentPunch[VPITCH] - RCSLastPunch[VPITCH], CurrentPunch[VYAW] - RCSLastPunch[VYAW], 0 };
		angle[VPITCH] -= NewPunch[VPITCH] * (settings.rcs_x / 50.f);
		angle[VYAW] -= NewPunch[VYAW] * (settings.rcs_y / 50.f);
	}
	Math::FixAngles(angle);
}
//--------------------------------------------------------------------------------
float Aimbot::GetFov()
{
	return 106.f;
	if (IsRcs() && settings.rcs && settings.rcs_fov_enabled) return settings.rcs_fov;
	if (!silent_enabled) return settings.fov;
	return settings.silent_fov > settings.fov ? settings.silent_fov : settings.fov;
}
//--------------------------------------------------------------------------------
C_BasePlayer* Aimbot::GetClosestPlayer(CUserCmd* cmd, int &bestBone)
{
	QAngle ang;
	Vector pVecTarget = g_LocalPlayer->GetEyePos();
	if (target && !kill_delay && settings.kill_delay > 0 && target->IsNotTarget()) {
		target = NULL;
		shot_delay = false;
		kill_delay = true;
		kill_delay_time = (int)GetTickCount() + settings.kill_delay;
	}
	if (kill_delay) {
		if (kill_delay_time <= (int)GetTickCount()) kill_delay = false;
		else return NULL;
	}
	target = NULL;
	int bestHealth = 100;
	float bestFov = 9999.f;
	float bestDamage = 0.f;
	float bestBoneFov = 9999.f;
	float bestDistance = 9999.f;
	float fov;
	int fromBone = settings.aim_type == 1 ? 0 : settings.hitbox;
	int toBone = settings.aim_type == 1 ? 7 : settings.hitbox;
	for (auto entity : *g_EntityList)
	{
		float damage = 0.f;
		if (!entity || entity == g_LocalPlayer || entity->GetClientClass()->m_ClassID != CCSPlayer)
			continue;
		auto player = (C_BasePlayer*)entity;
		if (player->IsNotTarget() || !settings.deathmatch && player->m_iTeamNum == g_LocalPlayer->m_iTeamNum)
			continue;
		for (int bone = fromBone; bone <= toBone; ++bone)
		{
			Vector eVecTarget = player->GetHitboxPos(bone);
			Math::VectorAngles(eVecTarget - pVecTarget, ang);
			Math::FixAngles(ang);
			float distance = Vector::Distance(pVecTarget, eVecTarget);
			if (settings.fov_type == 1)
				fov = GetRealDistanceFOV(distance, ang, cmd);
			else
				fov = GetFovToPlayer(cmd->viewangles, ang);
			if (fov > GetFov())
				continue;
			if (!g_LocalPlayer->CanSeePlayer(player, eVecTarget))
			{
				if (!settings.autowall)
					continue;
				damage = Autowall::GetDamage(eVecTarget);
				if (damage < settings.min_damage)
					continue;
			}
			if ((settings.priority == 1 || settings.priority == 2) && damage == 0.f)
				damage = Autowall::GetDamage(eVecTarget);
			int health = player->m_iHealth - damage;
			if (settings.check_smoke && IsLineGoesThroughSmoke(pVecTarget, eVecTarget))
				continue;
			if (settings.aim_type == 1 && bestBoneFov < fov)
				continue;
			bestBoneFov = fov;
			switch (settings.priority)
			{
			case 0:
				if (bestFov > fov)
				{
					target = player;
					bestBone = bone;
				}
			}
			continue;
			if (settings.priority == 0 && bestFov > fov ||
				settings.priority == 1 && bestHealth > health ||
				settings.priority == 2 && bestDamage < damage ||
				settings.priority == 3 && distance < bestDistance)
			{
				bestBone = bone;
				target = player;
				bestFov = fov;
				bestHealth = health;
				bestDamage = damage;
				bestDistance = distance;
			}
		}
	}
	return target;
}

#include <list>
#include <cmath>
#include <3DMath.h>
#include <linear.h>

struct TargetInfo
{
	Vector3 viewAngles;
	float crossHairDistance;
	float distance;
};

void Aim::OnCreateMove(CUserCmd* cmd, float t)
{
	if (!GetAsyncKeyState(VK_MENU)) return;

	static auto FindBestBone = [](C_BasePlayer* target, Vector3* pos) -> bool
	{
		static int bones[] = { HEAD_0, NECK_0, SPINE_3, SPINE_2, SPINE_1, SPINE_0 };
		CTraceFilter filter{ g_LocalPlayer };
		for (auto bone : bones)
		{
			auto bone_pos = target->GetHitboxPos(bone);
			Ray_t ray{ g_LocalPlayer->GetEyePos(), bone_pos };
			CGameTrace tr;
			g_EngineTrace->TraceRay(ray, MASK_SHOT | CONTENTS_GRATE, &filter, &tr);
			if (tr.hit_entity != target && tr.fraction <= 0.97f)
				continue;
			*pos = bone_pos;
			return true;
		}
		return false;
	};

	if (!g_LocalPlayer)
		return;
	int playerTeam = g_LocalPlayer->m_iTeamNum;
	auto eyePos = g_LocalPlayer->m_vecOrigin + g_LocalPlayer->m_vecViewOffset;
	auto rViewAngles = cmd->viewangles * _ncf::deg_to_rad;
	auto rAimPunchAngles = 2 * g_LocalPlayer->m_aimPunchAngle * _ncf::deg_to_rad;
	std::list<TargetInfo> enemyList;
	for (auto entity : *g_EntityList)
	{
		if (!entity || entity == g_LocalPlayer || entity->GetClientClass()->m_ClassID != CCSPlayer)
			continue;

		auto enemy = (C_BasePlayer*)entity;
		Vector3 targetPos;
		if (enemy->m_iTeamNum == playerTeam || enemy->IsDormant() || !enemy->IsAlive() || enemy->m_bGunGameImmunity || enemy->m_fFlags & FL_FROZEN || !FindBestBone(enemy, &targetPos))
			continue;

		float distance;
		auto tViewAngles = GetAimAngle(eyePos, targetPos, distance) - rAimPunchAngles;
		auto yaw_delta = std::abs(std::atan2(std::sin(tViewAngles.y - rViewAngles.y), std::cos(tViewAngles.x - rViewAngles.x)));
		if (yaw_delta > 45_degf)
			continue;
		enemyList.push_back({ tViewAngles, yaw_delta, distance });
	}

	if (enemyList.empty())
		return;
	enemyList.sort([](const TargetInfo& e1, const TargetInfo& e2) { return e1.crossHairDistance < e2.crossHairDistance; });
	
	auto&& target = enemyList.front();

	Vector3 delta = target.viewAngles - rViewAngles;
	if (!isfinite(delta.x) || !isfinite(delta.y))
		return;

	static auto rSetViewAngles = [](const Vector3& v)
	{
		auto x = std::clamp(v.x * _ncf::rad_to_deg, -89.f, 89.f);
		auto y = FixAngle(v.y, -180_degf) * _ncf::rad_to_deg;
		g_EngineClient->SetViewAngles({ x, y, 0 });
	};

	static auto LerpAngle = [](const Vector3& a, const Vector3& b, float t) -> Vector3
	{
		return { lerp_unclamped(a.x, b.x, t), a.y + GetLowerestAngleDiference(a.y, b.y, -180_degf), 0 };
	};

	if (target.crossHairDistance <= 1_degf || t == 0) //rage
	for (int i = 1; i <= 5; ++i) // used to not get vac kicked or unstrusted.
		rSetViewAngles(LerpAngle(rViewAngles, target.viewAngles, i * .2f));
	else
		rSetViewAngles(LerpAngle(rViewAngles, target.viewAngles, t));
}

void Aim::FixRecoil(CUserCmd* cmd)
{
	if (GetAsyncKeyState(VK_MENU) || !g_LocalPlayer) return;
	static Vector3 OldAimPunch;
	auto viewPunchAngle = g_LocalPlayer->m_aimPunchAngle;
	if (g_LocalPlayer->m_iShotsFired > 1)
	{
		auto nViewAngles = cmd->viewangles + 2 * (OldAimPunch - viewPunchAngle);
		nViewAngles.y = FixAngle(nViewAngles.y, -180.f, 360.f);
		g_EngineClient->SetViewAngles(nViewAngles);
		OldAimPunch = viewPunchAngle;
	}
	else
		OldAimPunch = Vector3::Zero;
}

//--------------------------------------------------------------------------------
bool Aimbot::IsNotSilent(float fov)
{
	return IsRcs() || !silent_enabled || silent_enabled && fov > settings.silent_fov;
}
//--------------------------------------------------------------------------------
void Aimbot::OnMove(CUserCmd *pCmd)
{
	if (!IsEnabled(pCmd)) {
		RCSLastPunch = { 0, 0, 0 };
		is_delayed = false;
		shot_delay = false;
		kill_delay = false;
		silent_enabled = settings.silent && settings.silent_fov > 0;
		target = NULL;
		return;
	}
	QAngle angles = pCmd->viewangles;
	QAngle current = angles;
	float fov = 180.f;
	if (!(settings.check_flash && g_LocalPlayer->IsFlashed()))
	{
		int bestBone = -1;
		if (target = GetClosestPlayer(pCmd, bestBone))
		{
			Math::VectorAngles(target->GetHitboxPos(bestBone) - g_LocalPlayer->GetEyePos(), angles);
			Math::FixAngles(angles);
			if (settings.fov_type == 1)
				fov = GetRealDistanceFOV(Vector::Distance(g_LocalPlayer->GetEyePos(), target->GetHitboxPos(bestBone)), angles, pCmd);
			else
				fov = GetFovToPlayer(pCmd->viewangles, angles);
			if (!settings.silent && !is_delayed && !shot_delay && settings.shot_delay > 0)
			{
				is_delayed = true;
				shot_delay = true;
				shot_delay_time = GetTickCount() + settings.shot_delay;
			}
			if (shot_delay)
			{
				pCmd->buttons &= ~IN_ATTACK;
				shot_delay = shot_delay_time <= GetTickCount();
			}
		}
	}
	CurrentPunch = g_LocalPlayer->m_aimPunchAngle;
	if (IsNotSilent(fov))
		RCS(angles, target);
	RCSLastPunch = CurrentPunch;
	if (target && IsNotSilent(fov))
		Smooth(current, angles, angles);
	Math::FixAngles(angles);
	pCmd->viewangles = angles;
	if (IsNotSilent(fov))
		g_EngineClient->SetViewAngles(angles);
	silent_enabled = false;
	if (g_LocalPlayer->m_hActiveWeapon->IsPistol() && settings.autopistol)
	{
		float server_time = g_LocalPlayer->m_nTickBase * g_GlobalVars->interval_per_tick;
		float next_shot = g_LocalPlayer->m_hActiveWeapon->m_flNextPrimaryAttack - server_time;
		if (next_shot > 0) {
			pCmd->buttons &= ~IN_ATTACK;
		}
	}
}
Aimbot g_Aimbot;