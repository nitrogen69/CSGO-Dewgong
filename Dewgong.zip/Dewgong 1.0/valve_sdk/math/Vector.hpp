#pragma once

#include <sstream>
#include <math_vectors.h>

using Vector = Vector3;

struct __declspec(align(16)) VectorAligned : Vector
{
	float w;
	VectorAligned() : w(1) {  };
	VectorAligned(float x, float y, float z, float w = 1) : Vector(x, y, z), w(w) {  }
	VectorAligned(const Vector& v) : Vector(v), w(1) {  }
};